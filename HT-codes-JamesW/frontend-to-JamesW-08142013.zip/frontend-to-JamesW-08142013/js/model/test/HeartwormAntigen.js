define([
    'jquery',
    'underscore',
    'backbone',
    'model/test/Base',
    'model/subtest/Boolean'
], function(
    $,
    _,
    Backbone,
    ModelTestBase,
    ModelSubtestBoolean
) {
    return ModelTestBase.extend({
        _defaultOrder: 700,

        _createSubtest: function(subtestData) {
            // all subtests are boolean
            return new ModelSubtestBoolean(subtestData);
        }
    });
});
