define([
    'backbone',
    'model/subtest/Base'
], function(
    Backbone,
    ModelSubtestBase
) {
    return ModelSubtestBase.extend({
        getValue: function() {
            /*
            var value = this.get('valueText');

            value = value || '';

            return value.toLowerCase() == "positive";
            */
            //show Detected or Clear
            var value=this.get("valueText"); 
            var value2=this.get('label');
            if(value2=='Glucose-Strip'||value2=='Protein'||value2=='Ketones'||value2=='Bilirubin'){
               value = value || '';
               return (value.toLowerCase()!="neg" && value.toLowerCase()!="negative");
            }
            else if(value2.toLowerCase().match(/parasite #/)){ 
               value = value || '';
               return (value != '');
            }      
            else{ 
               value = value || '';
               return (value.toLowerCase()=='pos'|| value.toLowerCase()=='positive');
            }

        }
    });
});
