define([
    'jquery',
    'backbone',
    'handlebars',
    'view/test/Base',
    'text!template/test/FelvFiv.html',
    'view/widget/TestOverview',
    'view/subtest/Boolean'
], function(
    $,
    Backbone,
    Handlebars,
    ViewTestBase,
    Template,
    ViewWidgetTestOverview,
    ViewSubtestBoolean
) {
    return ViewTestBase.extend({
        templateContent: Handlebars.compile(Template),

        render: function(parent) {
            var self = this,
                view;

            ViewTestBase.prototype.render.apply(this, arguments);
            
            this.$elContent.append(this.templateContent());

            // render test overview
            view = new ViewWidgetTestOverview({
                model: this.model,
                heading: this.getHeadingTemplate(),
                text: this.getTextTemplate()
            });

            view.render(this.$elContent.find('.test-overview'));

            // render all tests
            $.each(this.model.getAllTestCodes(), function(i, subtestModel) {
                view = new ViewSubtestBoolean({
                    model: subtestModel
                });

                view.render(self.$elContent.find('.boolean-container').eq(i));
            });
        },

        getHeadingTemplate: function() {
            var heading = [];

            if (this.model.hasFelvTest()) {
                heading.push('FeLV stands for Feline Leukemia Virus.');
            }

            if (this.model.hasFivTest()) {
                heading.push('FIV stands for Feline Immunodeficiency Virus.');
            }

            return Handlebars.compile(heading.join(' '));
        },

        getTextTemplate: function() {
            var text;

            if (this.model.hasFelvTest() && this.model.hasFivTest()) {
                // both tests present
                text = 'These tests look at {{patient.name}}’s blood to see if either virus is present.';
            } else {
                // only single test present
                text = 'This test looks at {{patient.name}}’s blood to see if the virus is present.';
            }

            return Handlebars.compile(text);
        },

        getTitle: function() {
            if (this.model.hasFelvTest() && this.model.hasFivTest()) {
                return 'FeLV AND FIV';
            } else if (this.model.hasFivTest()) {
                return 'FIV';
            } else if (this.model.hasFelvTest()) {
                return 'FeLV';
            } else {
                return this.model.getTitle();
            }
        }
    });
});
