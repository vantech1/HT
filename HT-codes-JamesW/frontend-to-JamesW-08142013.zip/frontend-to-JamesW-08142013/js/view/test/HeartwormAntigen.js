define([
    'jquery',
    'backbone',
    'handlebars',
    'view/test/Base',
    'text!template/test/HeartwormAntigen.html',
    'view/widget/TestOverview',
    'view/subtest/Boolean'
], function(
    $,
    Backbone,
    Handlebars,
    ViewTestBase,
    Template,
    ViewWidgetTestOverview,
    ViewSubtestBoolean
) {
    return ViewTestBase.extend({
        title: 'HEARTWORM',

        templateContent: Handlebars.compile(Template),

        render: function(parent) {
            var self = this,
                view;

            ViewTestBase.prototype.render.apply(this, arguments);
            
            this.$elContent.append(this.templateContent());

            // render test overview
            view = new ViewWidgetTestOverview({
                model: this.model,
                heading: Handlebars.compile('A heartworm is a parasitic worm that lives in the heart and surrounding arteries.'),
                text: Handlebars.compile('Heartworm is one of the most common infectious diseases in dogs and cats because it’s transmitted by infected mosquitoes – anywhere there are mosquitoes there is a risk of heartworm disease. If left undetected, it can be dangerous. Fortunately, it is very easy to prevent with regular medication.')
            });

            view.render(this.$elContent.find('.test-overview'));

            // render all tests
            view = new ViewSubtestBoolean({
                model: this.model.getAllTestCodes()[0]
            });

            view.render(self.$elContent.find('.boolean-container'));
        }
    });
});

