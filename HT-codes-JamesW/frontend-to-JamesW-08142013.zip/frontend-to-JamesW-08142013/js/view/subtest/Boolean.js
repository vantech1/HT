define([
    'jquery',
    'backbone',
    'handlebars',
    'model/subtest/Boolean',
    'text!template/subtest/Boolean.html',
    'text!template/subtest/BooleanParasite.html',
    'jquery-tooltip'
], function(
    $,
    Backbone,
    Handlebars,
    ModelSubtestBoolean,
    Template,
    TemplateParasite
) {
    return Backbone.View.extend({
        template: Handlebars.compile(Template),

        templateParasite: Handlebars.compile(TemplateParasite),

        constructor: function(config) {
            if (!config || !(config.model instanceof ModelSubtestBoolean)) {
                throw new Error('model not an instanceof ModelSubtestBoolean');
            }

            Backbone.View.apply(this, arguments);
        },

        render: function(parent) {
/*
            // render template
            this.setElement($(this.template({
                label: this.model.getLabel(),
                detected: this.model.getValue()
            })));

            this.$el.appendTo(parent);

            this.$el.tooltip({
                content: {
                    text: this.model.getDescription()
                },
                position: {
                    my: 'top center',
                    at: 'center',
                    target: this.$el.find('.icon')
                }
            });
*/
          var opLabel=this.model.getValueText().split(' ')[0]; 
          if((this.model.getLabel()).toLowerCase().match(/parasite #/)){
            // render template
            this.setElement($(this.template({
                label: opLabel,
                detected: this.model.getValue()
            })));

            this.$el.appendTo(parent);


            var self = this;
            this.$el2 = $(self.templateParasite({
                title: opLabel,
                description: this.model.getDescription()
            })), 
            elDetails = this.$el2.find('.details');


            this.$el.tooltip({
                content: {
                    //text: opLabel + "\r\n" + this.model.getDescription()
                    text: elDetails
                },
                position: {
                    my: 'top center',
                    at: 'center',
                    target: this.$el.find('.icon')
                }
            });

          }else{
            // render template
            this.setElement($(this.template({
                label: this.model.getLabel(),
                detected: this.model.getValue()
            })));

            this.$el.appendTo(parent);

            this.$el.tooltip({
                content: {
                    text: this.model.getDescription()
                },
                position: {
                    my: 'top center',
                    at: 'center',
                    target: this.$el.find('.icon')
                }
            });
          }

        }
    });
});
