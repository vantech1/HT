define([
    'app'
], function(
    App
) {
    // start the application
    App.init();
});
