define([
    'backbone',
    'model/subtest/Base'
], function(
    Backbone,
    ModelSubtestBase
) {
    return ModelSubtestBase.extend({
        getValue: function() {
            var value = this.get('valueText');

            value = value || '';

            return value.toLowerCase() == "positive";
        }
    });
});
