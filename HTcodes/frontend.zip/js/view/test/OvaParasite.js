define([
    'jquery',
    'backbone',
    'handlebars',
    'view/test/Base',
    'text!template/test/OvaParasite.html',
    'view/widget/TestOverview',
    'view/subtest/Boolean'
], function(
    $,
    Backbone,
    Handlebars,
    ViewTestBase,
    Template,
    ViewWidgetTestOverview,
    ViewSubtestBoolean
) {
    return ViewTestBase.extend({
        title: 'OVA & PARASITES',

        templateContent: Handlebars.compile(Template),

        render: function(parent) {
            var self = this,
                view;

            ViewTestBase.prototype.render.apply(this, arguments);
            
            this.$elContent.append(this.templateContent());

            // render test overview
            view = new ViewWidgetTestOverview({
                model: this.model,
                heading: Handlebars.compile('Intestinal parasites are the most common form of infectious disease in dogs and cats.'),
                text: Handlebars.compile('This test examines {{patient.name}}’s stool for young parasites and eggs.')
            });

            view.render(this.$elContent.find('.test-overview'));

            // render all tests
            $.each(this.model.getAllTestCodes(), function(i, subtestModel) {
                view = new ViewSubtestBoolean({
                    model: subtestModel
                });

                view.render(self.$elContent.find('.boolean-container').eq(i));
            });
        }
    });
});
