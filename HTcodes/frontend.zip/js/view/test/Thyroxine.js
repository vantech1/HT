define([
    'jquery',
    'backbone',
    'handlebars',
    'view/test/Base',
    'text!template/test/Thyroxine.html',
    'view/widget/TestOverview',
    'view/subtest/Range'
], function(
    $,
    Backbone,
    Handlebars,
    ViewTestBase,
    Template,
    ViewWidgetTestOverview,
    ViewSubtestRange
) {
    return ViewTestBase.extend({
        title: 'T4',

        templateContent: Handlebars.compile(Template),

        render: function(parent) {
            var view;

            ViewTestBase.prototype.render.apply(this, arguments);
            
            this.$elContent.append(this.templateContent());

            // render test overview
            view = new ViewWidgetTestOverview({
                model: this.model,
                heading: Handlebars.compile('The hormone Thyroxine, or T4, helps regulate {{patient.name}}’s growth and metabolism.'),
                text: Handlebars.compile('T4 is produced in the thyroid gland. It circulates through the body and tells the organs and systems how to use energy and how fast to work. This test measures how much T4 is in {{patient.name}}’s blood.')
            });

            view.render(this.$elContent.find('.test-overview'));

            // render range
            view = new ViewSubtestRange({
                model: this.model.getModelRange(),
                name: this.model.getReport().getDataPatient().name,
                skin: 'orange',
                unitOfMeasure: 'G/DL'
            });

            view.render(this.$elContent.find('.subtest-container'));
        }
    });
});
