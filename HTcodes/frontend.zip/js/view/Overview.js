define([
    'jquery',
    'backbone',
    'handlebars',
    'model/Report',
    'text!template/Overview.html',
    'config'
], function(
    $,
    Backbone,
    Handlebars,
    ModelReport,
    Template,
    Config
) {
    return Backbone.View.extend({
        template: Handlebars.compile(Template),
        templateMobilePhone: Handlebars.compile('<a href="tel:{{phone}}">{{phone}}</a>'),
        templateNonMobilePhone: Handlebars.compile('<span>{{phone}}</span>'),

        constructor: function(config) {
            if (!config || !(config.model instanceof ModelReport)) {
                throw new Error('model not an instanceof ModelReport');
            }

            Backbone.View.apply(this, arguments);
        },

        events: {
        },

        render: function(parent) {
            var clinic = this.model.getDataClinic(),
                phoneContainer,
                phoneEl;

            // render template
            this.setElement($(this.template({
                patient: this.model.getDataPatient(),
                doctor: this.model.getDataDoctor(),
                client: this.model.getDataClient(),
                clinic: clinic,
                requiresFollowUp: this.model.requiresFollowUp(),
                doctorComment: this.model.getDoctorComment(),
                nextStepsComment: this.model.getNextStepsComment(),
                date: this.model.getDate(),
                avatarUrl: this._getAvatarUrl(),
                printUrl: '#'
            })));

            phoneContainer = this.$el.find('.phone-container');

            if (Config.isMobile()) {
                phoneEl = $(this.templateMobilePhone({phone: clinic.phone}));
            } else {
                phoneEl = $(this.templateNonMobilePhone({phone: clinic.phone}));
            }

            phoneContainer.append(phoneEl);

            this.$el.appendTo(parent);
        },

        _getAvatarUrl: function() {
            var patient = this.model.getDataPatient(),
                species = this.model.getPatientSpecies();

            if (patient.photo) {
                return patient.photo;
            }

            switch(species) {
                case 'canine':
                    return 'images/overview/avatar/canine.png';

                case 'feline':
                    return 'images/overview/avatar/feline.png';

                default:
                    throw new Error('No default avatar specified for species: ' + species);
            }
        }
    });
});
