define([
    'jquery',
    'backbone',
    'handlebars',
    'model/subtest/Boolean',
    'text!template/subtest/Boolean.html',
    'jquery-tooltip'
], function(
    $,
    Backbone,
    Handlebars,
    ModelSubtestBoolean,
    Template
) {
    return Backbone.View.extend({
        template: Handlebars.compile(Template),

        constructor: function(config) {
            if (!config || !(config.model instanceof ModelSubtestBoolean)) {
                throw new Error('model not an instanceof ModelSubtestBoolean');
            }

            Backbone.View.apply(this, arguments);
        },

        render: function(parent) {
            // render template
            this.setElement($(this.template({
                label: this.model.getLabel(),
                detected: this.model.getValue()
            })));

            this.$el.appendTo(parent);

            this.$el.tooltip({
                content: {
                    text: this.model.getDescription()
                },
                position: {
                    my: 'top center',
                    at: 'center',
                    target: this.$el.find('.icon')
                }
            });
        }
    });
});
