define([
    'jquery',
    'backbone',
    'handlebars',
], function(
    $,
    Backbone,
    Handlebars,
    Template
) {
    return Backbone.View.extend({
        template: Handlebars.compile('<div class="view-widget-busy"></div>'),

        render: function(parent) {
            this.setElement($(this.template()));

            // append to parent
            this.$el.appendTo(parent);
        },

        show: function() {
            this.$el.fadeTo(100, 0.7);
        },

        hide: function() {
            this.$el.fadeOut();
        }
    });
});
